using NUnit.Framework;
using Altom.AltDriver;
using System;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using Spine;
using static EEFish;
using Unity.VisualScripting;
using UnityEngine;

public class NewAltTest:BaseAssert
{
    //Important! If your test file is inside a folder that contains an .asmdef file, please make sure that the assembly definition references NUnit.

    public AltDriver altDriver;
    private BaseActions action;

    //Before any test it connects with the socket

    [OneTimeSetUp]
    public void SetUp()
    {
        altDriver =new AltDriver();
        action = new BaseActions(altDriver);
        action.waitForObject("path", "/Main Camera");
        verifyEquals(action.getCurrentScreen(), "LessonBuilderScen");
       // Assert.AreEqual(action.getCurrentScreen(), "LessonBuilderScene");
        PlayGameThan35Age();
    }

    

   
    public void PlayGameThan35Age()
    {

        action.clickToDropDown("name", "Arrow");
        action.tapToElement("name", "Tuổi bé 8");
        Assert.AreEqual(action.getTextElement("path", "//Dropdown/Label"), "Tuổi bé 8");
        action.clickToChooseGame("PlayTheBalloon");
        action.chooseWord("beak");
        action.chooseWord("pear");
        action.clickToElement("text", "Build Lesson");
        Thread.Sleep(1000);
    }

    [Test]
    public void TC01_checkAudioPlayWhenStartGameWithAgeThan35()
    {
        action.waiForScreenPresent("EEPlayTheBalloon");
        action.waitForObject("name", "SoundManager");
        Thread.Sleep(2000);

        Assert.AreEqual( action.getPropertyInObject( "name"
            , "SoundManager"
            , "UnityEngine.AudioSource"
            , "clip.name"
            , "UnityEngine")
            , "AudioIntroGamePlayTheBalloon");

        Assert.IsTrue(action.getPropertyInObject("name"
            , "SoundManager"
            , "UnityEngine.AudioSource"
            , "playOnAwake"
            , "UnityEngine"));

    }

    [Test]
    public void TC02_checkAmountRowBallonWithAgeThan35()
    {
       
        Assert.AreEqual(action.getRowObjectInGame("EEPlayTheBalloon", "item(Clone)"), 3);

    }

    [Test]
    public void TC03_checkColorBallonWithAgeThan35()
    {
        var listColor = new List<string>();
        
            for (int index = 0; index < 9; index++) {
                var ballloonColor = action.getPropertyInObject(
                    "path", "//Ballloon_"
                    + index + "/Image"
                    , "UnityEngine.UI.Image"
                    , "sprite.name"
                    , "UnityEngine.UI"
                    );
                listColor.Add(ballloonColor);
            }

        Assert.AreEqual(listColor.Count, 9);

        var result = (from color in listColor
                     where color == "BalloonBlue"
                           && color == "BalloonRed"
                           && color == "BalloonOrange"
                     select color).Count();
        Assert.AreEqual(result,9);
    }

    [Test]
    public void TC04_checkAnswerBalloonWithAgeThan35()
    {
        Thread.Sleep(3000);
        int trueAnswer = 0;
        System.Random rand = new System.Random();
       
        var numbers = Enumerable.Range(0, (action.getAmountOfBalloonInGame("name", "Ballloon")) - 1)
                                            .OrderBy(x => rand.Next())
                                            .Take(action.getAmountOfBalloonInGame("name", "Ballloon"))
                                            .ToList();

        foreach (int number in numbers)
        {
            if (trueAnswer < 3)
            {
                action.tapToElement("name", "Ballloon_" + number);
                string imageAnswer = action.getPropertyInObject(
                        "path", "//Ballloon_"
                        + number + "/Image/imageAnswer"
                        , "UnityEngine.UI.Image"
                        , "sprite.name"
                        , "UnityEngine.UI"
                        );
                if (imageAnswer.Equals("3hXBd0xjRge2X9a8JQRYBslECCJH44Bl")
                    || imageAnswer.Equals("Vz6R4XZZCdPPvPpBEllhY8Kxs7qTamAa"))
                {
                    trueAnswer = trueAnswer + 1;

                }
            }
            else
            {
                break;
            }
            
            
        }
           
        Assert.AreEqual(3, trueAnswer);
    }

    //At the end of the test closes the connection with the socket
    [OneTimeTearDown]
    public void TearDown()
    {
        altDriver.Stop();
    }

}