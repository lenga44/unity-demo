﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Threading;
using Altom.AltDriver;
using Altom.AltDriver.Logging;
using UnityEngine;

public class BaseActions
{
    private AltDriver altDriver;
    public BaseActions(AltDriver altDriver)
    {
        this.altDriver = altDriver;
    }

    protected By getTypeElement(String type)
    {
        By by = By.PATH;
        switch (type)
        {
            case "name":
                by = By.NAME;
                break;
            case "path":
                by = By.PATH;
                break;
            case "text":
                by = By.TEXT;
                break;
            case "component":
                by = By.COMPONENT;
                break;
        }
        return by;
    }

    public AltObject findToElement(String type, String value)
    {
        return altDriver.FindObject(getTypeElement(type), value);
    }

    public List<AltObject> findToElements(String type, String value)
    {
        return altDriver.FindObjects(getTypeElement(type), value);
    }

    public AltObject findToElementByContain(String type, String value)
    {
        return altDriver.FindObjectWhichContains(getTypeElement(type), value);
    }

    public List<AltObject> findToElementsByContain(String type, String valueWhichContain)
    {
        Thread.Sleep(2000);
        return altDriver.FindObjectsWhichContain(getTypeElement(type), valueWhichContain);
    }

    public void waitForObjectWhichContains(String type, String valueWhichContain)
    {
        altDriver.WaitForObjectWhichContains(getTypeElement(type), valueWhichContain);
    }

    public List<string> getListNameToElement()
    {
       
        var listName = new List<string>();
        var objs = findToElementsByContain("name", "Iteam");
        foreach (var obj in objs)
        {
            listName.Add(obj.name);
        }

        return listName;
    }

    public Boolean hasTextInScrollView(String textSearch)
    {
        Boolean hasText = false;
        var obj = altDriver.FindObjectWhichContains(By.NAME,textSearch);
       if(obj != null)
        {
            hasText = true;
        }
            return hasText;
    }

    public void waitForObject(String type, String locator)
    {
        altDriver.WaitForObject(getTypeElement(type), locator);
    }

    public String getCurrentScreen()
    {
        return altDriver.GetCurrentScene();
    }

    public void clickToElement(String type, String locator)
    {
        waitForObject(type, locator);
        altDriver.Click(findToElement(type, locator).getScreenPosition());
    }

    public void clickToElementWhichContain(String type, String locator)
    {
        waitForObject(type, locator);
        altDriver.Click(findToElementByContain(type, locator).getScreenPosition());
    }

  

    public void clickToDropDown(String type, String locator)
    {
        clickToElement(type, locator);
        Thread.Sleep(1000);
    }

    public void tapToElement( String type, String locator)
    {
        findToElementByContain(type, locator).Tap();
    }

    public void clickToChooseGame(String gameName)
    {
        var obj = findToElementByContain("name", gameName);
        var nameObj = obj.name;
        String pathOfGame = "/Canvas/GameListLayout/content/" + nameObj + "/Text/BtnSelect";
        tapToElement("path", pathOfGame);
    }

    public void chooseWord(String word)
    {
        var objChild = findToElement("text", word);
        var objParent = objChild.getParent();
        var idWord = objParent.getParent().name;
        var pathOfWord = "/Canvas/WordsLayout/content/" + idWord + "/Toggle";
        tapToElement("path", pathOfWord);
    }

    public string getTextElement(String type, String locator)
    {
        return findToElement(type, locator).GetText();
    }

    public void waiForScreenPresent(String screenName)
    {
        altDriver.WaitForCurrentSceneToBe(screenName, 10);
    }

    public int getRowObjectInGame(String type, String locator)
    {
        var objs = findToElements("name", locator);
        return objs.Count;
    }

    public int getAmountOfBalloonInGame(String type, String locator)
    {
        var objs = findToElementsByContain(type, locator);
        return objs.Count;
    }

    public dynamic getPropertyInObject( String type, String locator, String componentName, String propertyName, String assemblyName)
    {
        Thread.Sleep(1000);
        waitForObject(type, locator);
        var obj = findToElement(type, locator);
        return obj.GetComponentProperty<dynamic>(componentName, propertyName, assemblyName);
    }
  
}

