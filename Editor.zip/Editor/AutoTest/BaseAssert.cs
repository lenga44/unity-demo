using NUnit.Framework;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BaseAssert : MonoBehaviour
{
    protected Boolean verifyEquals(dynamic actual, dynamic expected)
    {
        Boolean pass = true;
        try
        {
            Assert.AreEqual(actual, expected);
            Debug.Log("---------------PASSED--------------");
        }
        catch (AssertionException)
        {
            Debug.Log("---------------FAILED--------------");
            pass = false;
        }
        return pass;
    }

    protected Boolean verifyFalse(Boolean condition)
    {
        Boolean pass = true;
        try
        {
            Assert.IsFalse(condition);
            Debug.Log("---------------PASSED--------------");
        }
        catch (AssertionException)
        {
            Debug.Log("---------------FAILED--------------");
            pass = false;

        }
        return pass;
    }

    protected Boolean verifyTrue(Boolean condition)
    {
        Boolean pass = true;
        try
        {
            Assert.IsTrue(condition);
            Debug.Log("---------------PASSED--------------");
        }
        catch (AssertionException)
        {
            Debug.Log("---------------FAILED--------------");
            pass = false;

        }
        return pass;
    }

}
