using Mono.Cecil;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using Unity.VisualScripting;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

public class AutoBuild
{
    private static string sceneFolder = "./Assets/MonkeyX";
    private static string firstSceneName = "EEFindPair.unity";

    public static int StartBuild()
    {

        var listScene = GetAllScene(sceneFolder);
        AddSceneToBuildSetting(listScene);

        BuildPipeline.BuildPlayer(EditorBuildSettings.scenes, "./kien/BuildResult.exe", BuildTarget.StandaloneWindows, BuildOptions.None);
        
        return 0;
    }


    private static string[] GetAllScene(string folder)
    {
        DirectoryInfo dir = new DirectoryInfo(folder);
        FileInfo[] info = dir.GetFiles("*.unity", SearchOption.AllDirectories);

        string[] scenePaths = new string[info.Length];
        for(int i = 0; i < info.Length; i++)
        {
            var p = info[i].FullName;
            scenePaths[i] = p.Remove(0, p.IndexOf("Assets"));
        }

        //bring first scene to front
        int firstSceneIndex = (int)scenePaths.Select((v, i) => new { v, i })
            .Where(x => x.v.Contains(firstSceneName))
            .Select(x => x.i).ToList().FirstOrDefault();
        var tmp = scenePaths[0];
        scenePaths[0] = scenePaths[firstSceneIndex];
        scenePaths[firstSceneIndex] = tmp;

        return scenePaths;
    }

    private static void AddSceneToBuildSetting(string[] listScenePath)
    {
        List<EditorBuildSettingsScene> editorBuildSettingsScenes = new List<EditorBuildSettingsScene>();
        foreach (var scenePath in listScenePath)
        {
            editorBuildSettingsScenes.Add(new EditorBuildSettingsScene(scenePath, true));
        }
        EditorBuildSettings.scenes = editorBuildSettingsScenes.ToArray();
    }
}
